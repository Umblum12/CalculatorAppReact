import logo from './logo.svg';
import './App.css';
import CalculadoraWeb from './Components/calculadoraWeb';

function App() {
  return (
    <div className="App">
      <CalculadoraWeb></CalculadoraWeb>
    </div>
  );
}

export default App;
